YouTube LITE
by MRFIXIT2001

The full YouTube Kodi Addon is awesome but over complicates what I want to do. So I created this slimmed down version to search and save youtube videos.

I have added a built-in player so that the YouTube kodi addon is no longer a requirement. 
There is a setting in the addon that will allow you to use the youtube addon for playback if you still want to.

Due to the number of changes that youtube keeps making to it's API, and me having to keep fixing them,
I have created my own kodi repository to help with everyone keeping their addons updated.
You can get my repository here: https://mrfixit2001.github.io/

NOTE: I used pieces of my work from my Kodi Karaoke Reborn app.

The author is not responsible for the use of this addon. The author is not responsible for the content found using this addon. The author does not host or own any content found within this addon. The author is in no way affiliated with Kodi, Team Kodi, or the XBMC Foundation. This is a Non-profit resource, organized solely for educational purposes which is protected under the Fair-Use doctrine of the Copyright Act, Specifically section 107, which does promote freedom of expression, by permitting the unlicensed use of copyright-protected works.
