YouTube LITE
by MRFIXIT2001

The full YouTube Kodi Addon is awesome but over complicates what I want to do. So I created this slimmed down version to search and save youtube videos.

NOTE: I used pieces of my work from my Kodi Karaoke Reborn app.

The author is not responsible for the use of this addon. The author is not responsible for the content found using this addon. The author does not host or own any content found within this addon. The author is in no way affiliated with Kodi, Team Kodi, or the XBMC Foundation. This is a Non-profit resource, organized solely for educational purposes which is protected under the Fair-Use doctrine of the Copyright Act, Specifically section 107, which does promote freedom of expression, by permitting the unlicensed use of copyright-protected works.
